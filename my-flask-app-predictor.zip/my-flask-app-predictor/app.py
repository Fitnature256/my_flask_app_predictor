
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return "Welcome to the Virtual Football Predictor!"

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json

    # Extract input
    team_a = data.get("team_a")
    team_b = data.get("team_b")

    # Simple mock prediction logic
    if team_a and team_b:
        predicted = team_a if len(team_a) > len(team_b) else team_b
        return jsonify({
            "team_a": team_a,
            "team_b": team_b,
            "prediction": f"{predicted} is likely to win"
        })
    else:
        return jsonify({"error": "Please provide both team_a and team_b"}), 400

if __name__ == '__main__':
    app.run()
